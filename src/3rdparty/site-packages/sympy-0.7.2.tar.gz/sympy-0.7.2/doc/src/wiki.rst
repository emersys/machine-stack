Wiki
====

We have a public wiki: http://wiki.sympy.org

Anyone please feel free to contribute to it anything you find
interesting/useful to other users.

FAQ
---

`FAQ <https://github.com/sympy/sympy/wiki/Faq>`_ is one of the very useful wiki pages.
