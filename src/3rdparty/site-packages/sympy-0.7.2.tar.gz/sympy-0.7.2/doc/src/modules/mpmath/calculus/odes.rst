Ordinary differential equations
-------------------------------

Solving the ODE initial value problem (``odefun``)
..................................................

.. autofunction:: mpmath.odefun
