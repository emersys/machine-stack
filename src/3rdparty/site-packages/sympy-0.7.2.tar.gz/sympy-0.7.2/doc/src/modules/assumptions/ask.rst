===
Ask 
===

.. automodule:: sympy.assumptions.ask
   :members:
