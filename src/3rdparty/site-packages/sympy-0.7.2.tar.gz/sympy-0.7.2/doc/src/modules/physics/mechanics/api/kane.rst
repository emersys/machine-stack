=================================================
Kane's Method & Associated Functions (Docstrings)
=================================================

KanesMethod
===========

.. autoclass:: sympy.physics.mechanics.KanesMethod
   :members:

partial_velocity
================

.. automodule:: sympy.physics.mechanics.functions
   :members: partial_velocity
