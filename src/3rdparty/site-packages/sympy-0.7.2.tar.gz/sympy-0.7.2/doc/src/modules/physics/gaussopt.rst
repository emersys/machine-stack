===============
Gaussian Optics
===============

.. automodule:: sympy.physics.gaussopt
   :members:
