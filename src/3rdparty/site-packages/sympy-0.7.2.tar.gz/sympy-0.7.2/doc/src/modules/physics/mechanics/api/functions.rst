========================================
Related Essential Functions (Docstrings)
========================================

dynamicsymbols
==============

.. autofunction:: sympy.physics.mechanics.essential.dynamicsymbols


dot
===

.. autofunction:: sympy.physics.mechanics.functions.dot


cross
=====

.. autofunction:: sympy.physics.mechanics.functions.cross


outer
=====

.. autofunction:: sympy.physics.mechanics.functions.outer


express
=======

.. autofunction:: sympy.physics.mechanics.functions.express
