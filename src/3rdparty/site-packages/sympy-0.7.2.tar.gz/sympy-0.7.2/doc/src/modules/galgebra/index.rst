==================================
Geometric Algebra Module Docstring
==================================

.. automodule: sympy.galgebra

Documentation for Geometric Algebra module

Contents:

.. toctree::
   :maxdepth: 2

   GA.rst
   latex_ex.rst
