=======================
Kinematics (Docstrings)
=======================

Point
=====

.. automodule:: sympy.physics.mechanics.point
   :members:


kinematic_equations
===================

.. automodule:: sympy.physics.mechanics.functions
   :members: kinematic_equations
