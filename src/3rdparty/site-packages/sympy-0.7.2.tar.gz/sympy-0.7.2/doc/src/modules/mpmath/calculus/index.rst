Numerical calculus
==================

.. toctree::
   :maxdepth: 2

   polynomials.rst
   optimization.rst
   sums_limits.rst
   differentiation.rst
   integration.rst
   odes.rst
   approximation.rst
