========
Latex_ex
========

.. automodule:: sympy.galgebra.latex_ex
   :members:

