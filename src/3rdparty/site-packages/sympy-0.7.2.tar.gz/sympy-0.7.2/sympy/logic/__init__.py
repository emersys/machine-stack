from boolalg import to_cnf, And, Or, Not, Xor, Nand, Nor, Implies, Equivalent, ITE
from inference import satisfiable
