"""
A module for geometric algebra

"""
