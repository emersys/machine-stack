#define ZINT
#include "../../SuiteSparse/UMFPACK/Source/umf_solve.c"
