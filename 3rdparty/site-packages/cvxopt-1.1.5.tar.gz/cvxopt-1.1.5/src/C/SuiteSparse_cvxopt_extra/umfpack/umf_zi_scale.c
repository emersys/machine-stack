#define ZINT
#include "../../SuiteSparse/UMFPACK/Source/umf_scale.c"
