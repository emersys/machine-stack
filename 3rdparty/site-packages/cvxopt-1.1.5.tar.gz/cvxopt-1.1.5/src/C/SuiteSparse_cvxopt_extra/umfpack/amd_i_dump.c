#define DINT

#include "../../SuiteSparse/AMD/Source/amd_dump.c"
