#define ZINT
#include "../../SuiteSparse/UMFPACK/Source/umf_kernel_wrapup.c"
