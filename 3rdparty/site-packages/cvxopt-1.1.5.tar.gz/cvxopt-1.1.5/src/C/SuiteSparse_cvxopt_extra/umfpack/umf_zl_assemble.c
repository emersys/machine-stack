#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_assemble.c"
