#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umfpack_solve.c"
