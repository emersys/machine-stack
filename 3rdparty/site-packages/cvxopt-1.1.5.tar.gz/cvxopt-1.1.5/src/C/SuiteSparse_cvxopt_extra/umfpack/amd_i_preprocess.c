#define DINT

#include "../../SuiteSparse/AMD/Source/amd_preprocess.c"
