#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_build_tuples.c"
