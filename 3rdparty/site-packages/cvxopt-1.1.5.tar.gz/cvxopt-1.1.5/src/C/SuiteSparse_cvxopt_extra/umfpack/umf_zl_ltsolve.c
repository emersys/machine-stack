#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_ltsolve.c"
