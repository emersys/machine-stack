#define ZINT

#include "../../SuiteSparse/UMFPACK/Source/umf_init_front.c"
