#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umfpack_qsymbolic.c"
