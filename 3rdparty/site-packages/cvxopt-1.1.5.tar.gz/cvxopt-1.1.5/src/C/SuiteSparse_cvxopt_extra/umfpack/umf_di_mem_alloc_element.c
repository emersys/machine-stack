#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_mem_alloc_element.c"
