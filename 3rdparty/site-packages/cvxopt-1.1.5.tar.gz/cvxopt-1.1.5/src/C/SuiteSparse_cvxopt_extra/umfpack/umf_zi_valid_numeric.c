#define ZINT
#include "../../SuiteSparse/UMFPACK/Source/umf_valid_numeric.c"
