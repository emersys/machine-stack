#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umfpack_free_numeric.c"
