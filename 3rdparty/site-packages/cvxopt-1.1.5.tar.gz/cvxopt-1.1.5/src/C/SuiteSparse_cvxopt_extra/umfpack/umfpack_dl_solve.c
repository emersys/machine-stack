#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umfpack_solve.c"
