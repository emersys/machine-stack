#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umfpack_symbolic.c"
