#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_kernel.c"
