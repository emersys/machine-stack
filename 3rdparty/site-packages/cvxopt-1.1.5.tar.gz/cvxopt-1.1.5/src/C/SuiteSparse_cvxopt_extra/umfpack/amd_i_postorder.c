#define DINT

#include "../../SuiteSparse/AMD/Source/amd_postorder.c"
