#define ZINT
#include "../../SuiteSparse/UMFPACK/Source/umf_tuple_lengths.c"
