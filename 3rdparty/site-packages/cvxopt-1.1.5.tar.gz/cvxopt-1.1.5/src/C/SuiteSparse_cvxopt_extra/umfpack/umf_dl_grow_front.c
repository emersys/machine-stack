#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_grow_front.c"
