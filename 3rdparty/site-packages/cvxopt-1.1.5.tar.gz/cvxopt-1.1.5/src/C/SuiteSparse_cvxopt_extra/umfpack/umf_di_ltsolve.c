#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_ltsolve.c"
