.. AUTO-GENERATED FILE -- DO NOT EDIT!

zmq
===

:mod:`zmq`
----------
.. automodule:: zmq

.. currentmodule:: zmq

.. autofunction:: zmq.get_includes

