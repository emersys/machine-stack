.. AUTO-GENERATED FILE -- DO NOT EDIT!

utils.jsonapi
=============

Module: :mod:`utils.jsonapi`
----------------------------
.. automodule:: zmq.utils.jsonapi

.. currentmodule:: zmq.utils.jsonapi

Functions
---------


.. autofunction:: zmq.utils.jsonapi.dumps


.. autofunction:: zmq.utils.jsonapi.loads

